﻿namespace MolarMass_GroupLabB
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.sortButton = new System.Windows.Forms.Button();
            this.singlecharButton = new System.Windows.Forms.Button();
            this.sortNumButton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.chemFormBox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.totalMassBox = new System.Windows.Forms.TextBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // sortButton
            // 
            this.sortButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.sortButton.Location = new System.Drawing.Point(1035, 33);
            this.sortButton.Name = "sortButton";
            this.sortButton.Size = new System.Drawing.Size(174, 23);
            this.sortButton.TabIndex = 0;
            this.sortButton.Text = "Sort By Name";
            this.sortButton.UseVisualStyleBackColor = true;
            this.sortButton.Click += new System.EventHandler(this.sortButton_Click);
            // 
            // singlecharButton
            // 
            this.singlecharButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.singlecharButton.Location = new System.Drawing.Point(1035, 92);
            this.singlecharButton.Name = "singlecharButton";
            this.singlecharButton.Size = new System.Drawing.Size(174, 23);
            this.singlecharButton.TabIndex = 1;
            this.singlecharButton.Text = "Single Character Symbols";
            this.singlecharButton.UseVisualStyleBackColor = true;
            this.singlecharButton.Click += new System.EventHandler(this.singlecharButton_Click);
            // 
            // sortNumButton
            // 
            this.sortNumButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.sortNumButton.Location = new System.Drawing.Point(1035, 142);
            this.sortNumButton.Name = "sortNumButton";
            this.sortNumButton.Size = new System.Drawing.Size(174, 23);
            this.sortNumButton.TabIndex = 2;
            this.sortNumButton.Text = "Sort By Atomic #";
            this.sortNumButton.UseVisualStyleBackColor = true;
            this.sortNumButton.Click += new System.EventHandler(this.sortNumButton_Click);
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 677);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(90, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Chemical Formula";
            // 
            // chemFormBox
            // 
            this.chemFormBox.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.chemFormBox.Location = new System.Drawing.Point(122, 677);
            this.chemFormBox.Name = "chemFormBox";
            this.chemFormBox.Size = new System.Drawing.Size(686, 20);
            this.chemFormBox.TabIndex = 4;
            this.chemFormBox.TextChanged += new System.EventHandler(this.chemFormBox_TextChanged);
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(852, 680);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(103, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Approx. Molar Mass:";
            // 
            // totalMassBox
            // 
            this.totalMassBox.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.totalMassBox.BackColor = System.Drawing.SystemColors.MenuBar;
            this.totalMassBox.ForeColor = System.Drawing.Color.ForestGreen;
            this.totalMassBox.Location = new System.Drawing.Point(979, 680);
            this.totalMassBox.Name = "totalMassBox";
            this.totalMassBox.ReadOnly = true;
            this.totalMassBox.Size = new System.Drawing.Size(181, 20);
            this.totalMassBox.TabIndex = 6;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AllowUserToResizeColumns = false;
            this.dataGridView1.AllowUserToResizeRows = false;
            this.dataGridView1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllHeaders;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dataGridView1.Location = new System.Drawing.Point(12, 12);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(1017, 645);
            this.dataGridView1.TabIndex = 7;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1230, 748);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.totalMassBox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.chemFormBox);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.sortNumButton);
            this.Controls.Add(this.singlecharButton);
            this.Controls.Add(this.sortButton);
            this.Name = "Form1";
            this.Text = "MolarMassCalculator";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button sortButton;
        private System.Windows.Forms.Button singlecharButton;
        private System.Windows.Forms.Button sortNumButton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox chemFormBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox totalMassBox;
        private System.Windows.Forms.DataGridView dataGridView1;
    }
}

